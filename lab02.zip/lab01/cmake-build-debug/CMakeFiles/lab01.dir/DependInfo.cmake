
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/Users/bartek/Documents/0_szkola/pea/lab01/TSP.cpp" "CMakeFiles/lab01.dir/TSP.cpp.obj" "gcc" "CMakeFiles/lab01.dir/TSP.cpp.obj.d"
  "C:/Users/bartek/Documents/0_szkola/pea/lab01/main.cpp" "CMakeFiles/lab01.dir/main.cpp.obj" "gcc" "CMakeFiles/lab01.dir/main.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
